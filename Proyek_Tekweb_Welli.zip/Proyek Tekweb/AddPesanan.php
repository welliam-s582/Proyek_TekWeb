<?php
include "connect.php";
if ($_SERVER['REQUEST_METHOD'] == "POST") 
{
    $harga = $_POST['harga'];
    $id = $_POST['IdProduk'];
    $jumlah = $_POST['jumlah'];
    $submit = $_POST['submit'];
    $foto = $_POST['foto'];
    $nama = $_POST['nama'];
    $idcustomer = 1;
    #keranjang yg idcustomer yg status = 0 klo udh beli status = 1
    #beli -> if ada keranjang -> pesanan tok 
    #      -> else -> buat keranjang n pesanan baru dengan id keranjang barusan dibuat

    #status
    #0 -> blm dikirim ke penjual
    #1 -> sudah dikirim ke penjual blm di confirm 
    #2 -> sdh di confirm penjual
    #3 -> sudah dikirim oleh penjual
    #4 -> sudah sampai di customer belum di confirm customer
    #5 -> sudah di confirm customer (selesai)

    //masuk keranjang
    $query = mysqli_query($conn, "SELECT * FROM keranjang WHERE IdCustomer = $idcustomer AND status = 0");
    if(mysqli_num_rows($query) == 0)
    {
        #jika tidak ada keranjang available 
        $newkeranjang = mysqli_query($conn, "INSERT INTO keranjang VALUES (default, $idcustomer, 0, 'test')");
        $stmt = mysqli_query($conn, "SELECT * FROM keranjang ORDER BY IdKeranjang DESC LIMIT 1");
        $row = mysqli_fetch_assoc($stmt);
        $idkeranjang = $row['IdKeranjang'];
        $sql = mysqli_query($conn, "INSERT INTO pesanan VALUES (default, $harga, 0, sysdate(), $id, $idkeranjang)");
    }
    else
    {
        #jika ada keranjang available 
        $hasil = mysqli_fetch_assoc($query); #id keranjang = hasil 
        $idkeranjang = $hasil['IdKeranjang'];
        $sql = mysqli_query($conn, "INSERT INTO pesanan VALUES (default, $harga, 0, sysdate(), $id, $idkeranjang)");
    }
    
    header("Location: home.php?purchased");
}
