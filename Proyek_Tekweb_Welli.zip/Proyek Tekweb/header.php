<!DOCTYPE html>
<html lang="en">

<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <script src="https://kit.fontawesome.com/a076d05399.js"></script>
</head>

<body>
  <div class="contain">
    <nav class="navbar navbar-expand-sm navbar-dark" style="background-color:gold">
      <ul class="navbar-nav pb-0">
        <li class="nav-item active">
          <a class="nav-link" href="home.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="Keranjang.php">Keranjang</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="#">Link</a>
        </li>
        <li class="nav-item">
          <a class="nav-link disabled" href="#">Disabled</a>
        </li>
      </ul>
      <!-- <div class="text-center">Andre Komputer</div> -->
      <!-- <p class="text-center">Andre Komputer</p> -->
    </nav>
    <div class="d-flex justify-content-start pb-3" style="background-color:gold">
      <h1 class="text-left pt-0 pl-4" style="color:black">Andre Komputer</h1>
      <form action='searched_item.php' method='post' style="width:50%">
        <div class="input-group">
          <input class="form-control form-control-sm mt-3 w-75" style="margin-left: 6%" type="text" placeholder="Search" aria-label="Search" name="search" id="search-text">
          <div class="input-group-append">
            <button id="search-btn" style="background:none; border:none"><a href="searched_item.php"><i class="fas fa-search fa-2x mt-3 ml-1 text-primary" aria-hidden="true"></a></i></button>
          </div>
        </div>
      </form>
    </div>
  </div>
  <!--
 <script src="assets/jquery/jquery-3.5.1.min.js"></script>
        <script src="assets/popper/popper.min.js"></script>
        <script src="assets/bootstrap/js/bootstrap.js"></script>

        <script>
            $("#search-btn").click(function(){
                var search = $("#search-text").val();

                $.ajax({
                    url: '/tugas/search.php',
                    method: 'POST',

                    data: 
                    {
                      search: search,
                        
                    },

                    success: function(data) 
                    {
                        window.location = data['redirect'];
                    },

                    error: function($xhr, textStatus, errorThrown) 
                    {
                        alert($xhr.responseJSON['error']);
                    }
                });
            });
     
            
        </script>
         !-->
</body>

</html>