<?php
require "connect.php";
$limit = 3;
$jumlah = 1;

?>


<!DOCTYPE html>
<html>
<title></title>

<head>
    <title></title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>

<?php include "header.php" ?>

<body>
    <div class="container-xl p-3">

        <div class="row">
            <div class="card m-3 col-3">
                <!-- <img class="card-img-top" src="Mouse.jpg" alt="photo" style="width: auto; height:400px ;"> -->
                <?php
                if ($_SERVER['REQUEST_METHOD'] == "POST") {
                    $idproduk = $_POST['id_produk'];
                }
                $query = mysqli_query($conn, "SELECT * FROM `produk` WHERE IdProduk = $idproduk");
                //$allProduk = mysqli_fetch_array($query);
                //$row = mysqli_fetch_assoc($query);      
                $i = 0;
                //$limit =3;
                $row = mysqli_fetch_assoc($query);
                echo '<div <center><img src="' . $row['foto_filepath'] . '" class="rounded mx-auto d-block" alt="Los Angeles" style="height:200px;"></center></div>';
                ?>
            </div>
            <div class="card m-3 col">
                <div class="row">
                    <div class="col-8 py-3">
                        <!-- <h3><b>Product Name</b></h3> -->
                        <?php
                        echo '<h3><b>' . $row['Nama'] . '</b></h3>'
                        ?>
                    </div>
                    <div class="col-5 py-3 text-muted">Harga</div>
                    <input class="col-6 py-3" style="font-size: 24px; border: none;" id="harga" value="<?php echo '' . $row['Harga'] . ''; ?>" disabled="disabled">
                </div>
                <div class="row">
                    <div class="col-5 text-muted">Jumlah</div>
                    <div class="card col-5 px-3" style="border: none;">
                        <div class="row">
                            <p class="mx-3">Stok
                                <?php
                                echo '' . $row['Stock'] . '';
                                ?>
                            </p>
                        </div>
                        <div class="row">
                            <button type="button" class="btn btn-success my-2 mx-3" id="sub"> - </button>
                            <input type="text" id="num" value="<?php echo $jumlah ?>" class="my-2 col-2 text-center">
                            <button type="button" class="btn btn-success my-2 mx-3" id="plus"> + </button>
                        </div>
                        <div class="row">
                            <input type="text" class="m-2 col-9" placeholder="Tulis catatan untuk penjual">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <nav class="navbar navbar-expand-sm bg-light">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="#description">Deskripsi</a>
                </li>
            </ul>
        </nav>
        <div id="description" class="my-3 col-12">
            <?php
            echo '' . $row['Deskripsi'] . ''
            ?>
        </div>

        <!-- Buy Modal -->
        <div class="modal fade" id="buy-modal" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-m" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Konfirmasi Pembelian</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form action="AddPesanan.php" method="POST">
                        <div class="modal-body">
                            <div>
                                <label for="product name">
                                    <?php
                                    echo  '<div><b>' . $row['Nama'] . '</b></div>';
                                    echo '<div><img src="' . $row['foto_filepath'] . '" class="rounded mx-auto d-block" alt="Los Angeles" style="height:200px;"></center></div>';
                                    ?>

                                </label>
                            </div>
                            <div>
                                <label for="Harga">Harga: </label>
                                <input type="text" id="Harga" name="Harga" disabled="disabled">
                            </div>
                            <input type="hidden" name="IdProduk" value="<?php echo $row['IdProduk'] ?>">
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-danger" name="submit" value="0"> Beli</button>
                        </div>
                </div>
            </div>
        </div>

        <footer class="text-right">
            <label for="total">  Total:
                <input type="text" name="total" id="total" disabled value="<?php echo $row['Harga'] ?>">
            </label>
            <button type="button" class="btn btn-danger col-2 mx-2" id="Buy"> Beli </button>
            <button type="submit" class="btn btn-light col-2" name="submit" value="1" id="cart"> Masuk Keranjang </button>
            <input type="hidden" name="jumlah" id="jumlah">
            <input type="hidden" name="foto" value="<?php echo $row['foto_filepath'];?>">
            <input type="hidden" name="nama" value="<?php echo $row['Nama'];?>">
            <input type="hidden" name="harga" id="price" value="1">
            </form>
        </footer>


        <script>
        $(function() {
            $("#plus").click(function() {
                var stok = <?php echo $row['Stock'] ?>;
                var nums = $("#num").val();
                var harga = $("#harga").val();
                harga = parseFloat(harga);
                nums = parseFloat(nums);
                if(nums < stok)
                {
                    nums = nums + 1;
                }
                var total = nums*harga;
                $("#num").val(nums);
                $("#total").val(total);

            });
            $("#sub").click(function() {
                var num = $("#num").val();
                num = parseFloat(num);
                if (num > 1) {
                    num = num - 1;
                }
                $("#num").val(num);
            });
            $("#Buy").click(function() {
                var jumlah = $("#num").val()
                jumlah = parseInt(jumlah);
                var harga = $("#harga").val();
                harga = parseInt(harga);
                var total = harga * jumlah;
                $("#Harga").val(total);
                $("#total").val(total)
                $("#jumlah").val(jumlah);
                $("#price").val(total);
                $("#buy-modal").modal();
            });
            $("#cart").click(function(){
                var jumlah = $("#num").val()
                jumlah = parseInt(jumlah);
                var harga = $("#harga").val();
                harga = parseInt(harga);
                var total = harga * jumlah;
                $("#jumlah").val(jumlah);
                $("#price").val(total);
            });
        });
    </script>
</body>




</html>