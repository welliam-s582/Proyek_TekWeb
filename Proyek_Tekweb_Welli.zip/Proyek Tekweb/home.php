<?php
  require 'connect.php';
  $limit = 3;
  include 'header.php'; 
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Andre Komputer</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<style>
  
  #myCarousel .card img
  {
    max-height: 150px;
    
  }
  
  
</style>
<body>  
  <div class="contai bg-light ">
  
  <div id="myCarousel" class="carousel slide shadow-sm mb-3 bg-white" data-ride="carousel">

    <!-- Indicators -->
    <div>
      <ul class="carousel-indicators">
        <?php
          //$limit =3;
          for($i = 0; $i <$limit;$i++)
          {
            if($i==0){
              echo'<li data-target="#myCarousel" data-slide-to="'.$i.'" class="active"></li>';
            }
            else{
              echo'<li data-target="#myCarousel" data-slide-to="'.$i.'"></li>';
            }
          }        
        ?>  
        <!-- <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
        <li data-target="#myCarousel" data-slide-to="1"></li>
        <li data-target="#myCarousel" data-slide-to="2"></li>     -->
      </ul>
    </div>

    <!-- Wrapper for slides -->    
    <div class="carousel-inner pb-5 pt-4 pl-5" style="width: 100%;">

      <?php
        $query = mysqli_query($conn,"SELECT * FROM `produk` WHERE 1 Limit $limit");
        //$allProduk = mysqli_fetch_array($query);
        //$row = mysqli_fetch_assoc($query);      
        $i = 0;
        //$limit =3;
        while($row = mysqli_fetch_assoc($query)) 
        {
          if($i==0)
          {?>
            <div class="carousel-item active card mb-3 ml-5" style="max-width: 1240px;">
                <form action="ProductPage.php" method="POST">
                  <div class="row no-gutters" onclick="this.parentNode.submit()">
                    <div class="col-md-4">
                      <?php echo '<div class="pt-2"><center><img src="'.$row['foto_filepath'].'" class="rounded mx-auto d-block" alt="Los Angeles"></center></div>';?>
                    </div>
                    <div class="col-md-8">
                      <div class="card-body">
                        <?php echo '<h5 class="card-title">'.$row['Nama'].'</h5>';?>
                        <?php echo '<h5 class="card-text">'.$row['Deskripsi'].'</h5>';?>
                        
                      </div>
                    </div>
                  </div>
                  <?php echo '<input type="hidden" id="id_produk" name="id_produk" value="'.$row['IdProduk'].'">'?>
                </form>
            </div>
          <?php
            
            $i++;
          }
          else
          {?>
            
              <div class="carousel-item card mb-3 ml-5" style="max-width: 1240px;">
                <form action="ProductPage.php" method="POST">
                  <div class="row no-gutters" onclick="this.parentNode.submit()">
                    <div class="col-md-4">
                      <?php echo '<div class="pt-2"><center><img src="'.$row['foto_filepath'].'" class="rounded mx-auto d-block" alt="Los Angeles"></center></div>';?>
                    </div>
                    <div class="col-md-8">
                      <div class="card-body">
                        <?php echo '<h5 class="card-title">'.$row['Nama'].'</h5>';?>
                        <?php echo '<h5 class="card-text">'.$row['Deskripsi'].'</h5>';?>
                      </div>
                    </div>
                  </div>
                  <?php echo '<input type="hidden" id="id_produk" name="id_produk" value="'.$row['IdProduk'].'">'?>
                </form>
              </div>
              
          <?php
           
          }
        }
      ?>

    </div>

    <!-- Left and right controls -->
    <div class="control">
      <a class="carousel-control-prev" href="#myCarousel" data-slide="prev">
        <span class="carousel-control-prev-icon"></span>
      </a>
      <a class="carousel-control-next" href="#myCarousel" data-slide="next">
        <span class="carousel-control-next-icon"></span>
      </a>
    </div>

  </div>
  
  <?php include "toppicks.php"?>

</div>
<script>
$(document).ready(function(){
  $("#myCarousel").carousel("cycle");
});
</script>


</body>
</html>
