<?php
require 'includes.php';
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $data = $_POST['bar'];
    $updateStatus =  "UPDATE `keranjang` SET `status`= 2 WHERE IdKeranjang = '$data'";
    if ($conn->query($updateStatus) === TRUE) {
        echo "Record updated successfully";
    } else {
        echo "Error updating record: " . $conn->error;
    }
}
?>
