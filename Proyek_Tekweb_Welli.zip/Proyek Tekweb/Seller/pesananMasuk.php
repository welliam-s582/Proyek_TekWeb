<?php require 'includes.php' ?>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.22/css/jquery.dataTables.css">
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.js"></script>

<body>
    <div class="row">
        <div class="col-sm-12 col-md-6">

        </div>
        <div class="col-sm-12 col-md-6">

        </div>
    </div>



    <div class="container-xl">


        <table id="myTable" class="table table-bordered table-hovered mt-3 display">
            <thead>
                <tr>
                    <th>#<i class="fa fa-arrows-v" style="font-size:24px; color:black;"></i></th>
                    <th>Id Pelanggan<i class="fa fa-arrows-v" style="font-size:24px; color:black;"></i></th>
                    <th>Nama Pelanggan<i class="fa fa-arrows-v" style="font-size:24px; color:black;"></i></th>
                    <th>Alamat Pelanggan<i class="fa fa-arrows-v" style="font-size:24px"></i></th>
                    <th>Pesanan<i class="fa fa-arrows-v" style="font-size:24px"></i></th>
                    <th>Total Pembelian<i class="fa fa-arrows-v" style="font-size:24px"></i></th>
                    <th>Konfirmasi<i class="fa fa-arrows-v" style="font-size:24px"></i></th>
                </tr>
            </thead>
            <tbody class="tb">
                <?php
                $allproduk = mysqli_query($conn, "SELECT * FROM `keranjang` JOIN customer on keranjang.IdCustomer=customer.IdCustomer where keranjang.status = 1");
                $total = mysqli_query($conn, "SELECT SUM(Total_Harga) FROM (SELECT SUM(ker.Total_Harga) as total
                FROM (SELECT Total_Harga FROM `keranjang` JOIN pesanan ON keranjang.IdKeranjang = pesanan.IdKeranjang WHERE keranjang.status = 1  AND keranjang.IdKeranjang = 54) as ker");
                $i = 1;
                //$limit =3;
                while ($row = mysqli_fetch_assoc($allproduk)) {
                    $idkeranjang = $row['IdKeranjang'];
                    $rowtotal = mysqli_fetch_assoc(mysqli_query($conn, "SELECT SUM(ker.Total_Harga) as total
                    FROM (SELECT Total_Harga FROM `keranjang` JOIN pesanan ON keranjang.IdKeranjang = pesanan.IdKeranjang WHERE keranjang.status = 1  AND keranjang.IdKeranjang = $idkeranjang) as ker"));
                    echo '<tr>';
                    echo '<td>' . $i . '</td>';
                    echo '<td>' . $row['IdCustomer'] . '</td>';
                    echo '<td>' . $row['Nama'] . '</td>';
                    echo '<td>' . $row['Alamat'] . '</td>';
                    echo '<td>
                <form action="detilPesananMasuk.php" id="utilities" class="d-flex justify-content-between mb-3" method="POST">
                    <input type="hidden" value="' . $idkeranjang . '" name="idkeranjang">
                    <input type="submit" value="Lihat Pesanan" class="btn btn-success">
                </form></td>';
                    echo '<td>' . $rowtotal['total'] . '</td>';
                    echo '<td>
                    <form id="foo">                        
                        <input class="dat"type="hidden" id="bar" name="bar" type="text" value="' . $idkeranjang . '" />                    
                        <input class="btn btn-success confirmbutton" type="submit" value="Confirm" />
                    </form></td>';
                    echo '</tr>';
                    $i++;
                }
                ?>
            </tbody>
        </table>
    </div>
    <script>
        $(document).ready(function() {
            $('#myTable').DataTable();

        });
        var values = $('.dat').serialize();
        $(".confirmbutton").click(function() {
            $.ajax({
                url: "confirm.php",
                type: "POST",
                data: values,
                success: function(response) {
                    
                    // You will get response from your PHP page (what you echo or print)
                },
                error: function(jqXHR, textStatus, errorThrown) {
                    console.log(textStatus, errorThrown);
                }
            });
        });

        // $(".confirmbutton").click(function() {
        //     $.ajax({
        //         url: "confirm.php",
        //         type: "POST",
        //         async: false,
        //         mydata: "gg",
        //         success: function(result) {
        //             $("body").html(result);
        //         }
        //     });
        // });
    </script>
</body>