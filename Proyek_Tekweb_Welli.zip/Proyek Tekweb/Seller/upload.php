<body>
    <?php
    require '../connect.php';
    if ($_SERVER['REQUEST_METHOD'] == "POST") {
        $harga = $_POST['harga'];
        $nama = $_POST['nama'];
        $kategori = $_POST['kategori'];
        $deskripsi = $_POST['desc'];
        $stok = $_POST['StokAwal'];
    }

        $targetDir = "productPicture/";
        $uploadDir = "../productPicture/";
        $timestamp = date("Y-m-d_H-i-s");
        $BaseName = basename($_FILES['file']['name']);
        $FileType = strtolower(pathinfo($BaseName, PATHINFO_EXTENSION));
        $newName = $BaseName.$timestamp.".".$FileType;
        $targetFile = $targetDir.$newName;
        $uploadfile = $uploadDir.$newName;

        $upload = move_uploaded_file($_FILES["file"]["tmp_name"], $uploadfile);
        if ($upload) {
            echo "upload berhasil";
        } else {
            echo "upload gagal";		
        }
        $filepath = $targetFile;


        /* ************************************************************* QUERY ****************************************************************** */


        $row = mysqli_query($conn, "INSERT INTO `produk`(`IdProduk`, `Harga`, `Stock`, `foto_filepath`, `id_kategori`, `Nama`, `Deskripsi`)
         VALUES ('','$harga', '$stok' ,'$filepath','$kategori','$nama','$deskripsi')");
        //echo $_FILES["cv"]["tmp_name"];
        if ($row) {
            echo '<script> alert "sukses menambahkan ke database"</script>';
            header("Location: index.php");
            exit();
        } else {
            echo '<script> alert "gagal menambahkan ke database"</script>';
            header("Location: index.php");
            exit();
        }


        /* ************************************************************* QUERY ****************************************************************** */
    
    ?>
</body>