<?php require 'includes.php' ?>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.22/css/jquery.dataTables.css">
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.js"></script>

<body>
    <?php
    if ($_SERVER['REQUEST_METHOD'] == "POST") {
        $idkeranjang = $_POST['idkeranjang'];
    }
    ?>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.22/css/jquery.dataTables.css">
    <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.js"></script>

    <body>
        <div class="container-xl">


            <div class="row">
                <div class="col-sm-12 col-md-6">

                </div>
                <div class="col-sm-12 col-md-6">

                </div>
            </div>

           


            <table id="myTable" class="table table-bordered table-hovered mt-3 display">
                <thead>
                    <tr>
                        <th>#<i class="fa fa-arrows-v" style="font-size:24px; color:black;"></i></th>
                        <th>Nama<i class="fa fa-arrows-v" style="font-size:24px; color:black;"></i></th>
                        <th>Lihat Barang<i class="fa fa-arrows-v" style="font-size:24px; color:black;"></i></th>
                        <th>Deskripsi<i class="fa fa-arrows-v" style="font-size:24px"></i></th>
                        <th>Kategori<i class="fa fa-arrows-v" style="font-size:24px"></i></th>
                        <th>Stok<i class="fa fa-arrows-v" style="font-size:24px"></i></th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $getkeranjang = mysqli_query($conn, "SELECT * FROM `keranjang` WHERE IdKeranjang = $idkeranjang");
                    while ($rowk = mysqli_fetch_assoc($getkeranjang)) {
                        $idkeranjang = $rowk['IdKeranjang'];
                        $allproduk = mysqli_query($conn, "SELECT * FROM `pesanan` JOIN produk ON pesanan.id_Produk = produk.IdProduk JOIN kategori ON produk.id_kategori = kategori.IdKategori where pesanan.IdKeranjang = $idkeranjang");
                        $i = 1;
                        //$limit =3;
                        while ($row = mysqli_fetch_assoc($allproduk)) {
                            echo '<tr>';
                            echo '<td>' . $i . '</td>';
                            echo '<td>' . $row['Nama'] . '</td>';
                            echo '<td><button type="button" class="btn btn-success">Lihat</button></td>';
                            echo '<td>' . $row['Deskripsi'] . '</td>';
                            echo '<td>' . $row['Nama_Kategori'] . '</td>';
                            echo '<td>' . $row['Stock'] . '</td>';
                            echo '</tr>';
                            $i++;
                        }
                    }
                    ?>
                </tbody>
            </table>
            <script>
                $(document).ready(function() {
                    $('#myTable').DataTable();
                });
            </script>
        </div>
    </body>

</body>