

<style>
    .pesanan{
        height: 180px;        
        background-color: white;
    }
    
</style>
<body>
    <div class="row pt-3 p-3 pb-3 bg-light rowpesanan">
        <div class="col pesanan border mr-3 rounded p-3">
            <p>PESANAN MASUK</p>
            <?php 
                $pesananMasuk = mysqli_query($conn,"SELECT * FROM `keranjang` WHERE keranjang.status = 1");
                $totalPesanan = mysqli_num_rows($pesananMasuk);
                echo '<h1>'.$totalPesanan.'</h1>';
             ?>
            
        </div>

        <div class="col pesanan border mr-3 rounded p-3">
            <p>PESANAN BELUM DIKIRIM</p>
            <?php 
                $pesananMasuk = mysqli_query($conn,"SELECT * FROM `keranjang` WHERE keranjang.status = 2");
                $totalPesanan = mysqli_num_rows($pesananMasuk);
                echo '<h1>'.$totalPesanan.'</h1>';
             ?>
        </div>

        <div class="col pesanan border mr-3 rounded p-3">
            <p>PESANAN DALAM PERJALANAN</p>
            <?php 
                $pesananMasuk = mysqli_query($conn,"SELECT * FROM `keranjang` WHERE keranjang.status = 3");
                $totalPesanan = mysqli_num_rows($pesananMasuk);
                echo '<h1>'.$totalPesanan.'</h1>';
             ?>
        </div>

        <div class="col pesanan border mr-3 rounded p-3">
            <p>PESANAN SAMPAI (belum dikonfirmasi pembeli)</p>
            <?php 
                $pesananMasuk = mysqli_query($conn,"SELECT * FROM `keranjang` WHERE keranjang.status = 4");
                $totalPesanan = mysqli_num_rows($pesananMasuk);
                echo '<h1>'.$totalPesanan.'</h1>';
             ?>
        </div>
    </div>
</body>
<script>
    $('.pesanan').click(function()
    {
        window.location.replace("pesananMasuk.php");
    });
</script>
</html>