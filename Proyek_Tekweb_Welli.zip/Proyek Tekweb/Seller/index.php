<?php 
include 'includes.php';
include '../connect.php' ;

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.css"/>
    <link rel="stylesheet" href="assets/linearicons/style.css"/>

    <link rel="stylesheet" href="assets/jquery-confirm/jquery-confirm.css"/>
    <title>Document</title>
</head>
<body>
    <?php require '../header.php'; ?>
    <div class="container-fluid bg-light pb-3">
        <?php             
            require 'pesanan.php';
        ?>        
         <script src="assets/jquery/jquery-3.5.1.min.js"></script>
        <script src="assets/popper/popper.min.js"></script>
        <script src="assets/bootstrap/js/bootstrap.js"></script>

        <script src="assets/jquery-confirm/jquery-confirm.js"></script>
        <?php require 'produk.php'; ?>
    </div>     
</body>
</html>