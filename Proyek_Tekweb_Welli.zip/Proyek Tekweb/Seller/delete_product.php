<?php
    require 'includes.php';
    header("Content-Type: application/json");

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
        $result = array(
            "status" => 1,
            "error" => "",
            'redirect' => ""
        );
    
        $id = $_POST['id'];
        $data= mysqli_query($conn,"SELECT * FROM pesanan WHERE id_Produk = $id");
        $totalPesanan = mysqli_num_rows($data);
        if($totalPesanan>=1)
        {
            header("HTTP/1.1 400 Bad Request");
            $result['status'] = 0;
            $result['error'] = 'Someone order this Product and has not Arrived yet !';
        }
        else
        {
            $sql = "DELETE FROM produk WHERE IdProduk = $id";

            if ($conn->query($sql) === TRUE) {
                $result['redirect'] = '/Proyek Tekweb/Proyek Tekweb/Seller/index.php';
            }
        
        }
        echo json_encode($result);
    } 
    else {
        header("HTTP/1.1 400 Bad Request");
        $error = array(
            'error' => 'Method not Allowed'
        );
    
        echo json_encode($error);
    }

?>