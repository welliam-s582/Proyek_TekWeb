<?php require 'includes.php'; ?>
<style>

</style>
<link rel="stylesheet" href="../libraries/dropzone-5.7.0/dist/dropzone.css">
<link rel="stylesheet" href="../libraries/dropzone-5.7.0/dist/basic.css">
<script src="../libraries/dropzone-5.7.0/dist/dropzone.js"></script>

<body>
    <div class="container-xl allwrapper mt-3 shadow-lg pb-4 pt-2 rounded">
        <div class="container-fluid upload_gambar border border-white rounded mt-3 mb-3">
            <h2>Upload Foto Produk</h2>
            <!--Grid column-->
            <!-- <form action="upload.php" class="dropzone" id="foto" method="POST" required></form> -->
            <form enctype="multipart/form-data" action="upload.php" method="POST" id="gambar">
                <!-- MAX_FILE_SIZE must precede the file input field -->
              
                <!-- Name of input element determines name in $_FILES array -->
                Upload Gambar: <input name="file" type="file" accept="image/x-png,image/gif,image/jpeg" />



                <!--Grid column-->



                <h2 class="mt-3">Informasi Produk</h2>

                <label for="nama" class="mt-2">Nama Produk:</label>
                <input type="text" class="form-control" id="nama" name="nama" placeholder="ex: ROG{nama brand} STRIX B550-XE{nama produk} GAMING WIFI{info tambahan}: ROG STRIX B550-XE GAMING WIFI" required>


                <label for="harga" class="mt-2">Harga:</label>
                <input type="number" placeholder="Harga Dalam Rupiah" class="form-control" id="harga" name="harga" required>

                <label for="StokAwal" class="mt-2">Stok Awal:</label>
                <input type="number" placeholder="Stok Awal" class="form-control" id="StokAwal" name="StokAwal" required>

                <div id="form-group">
                    <label for="kategori" class="mt-2">Kategori:</label>
                    <select id="kategori" name="kategori" class="form-control" required>
                        <?php
                        $query = mysqli_query($conn, "SELECT * FROM `kategori` WHERE 1");
                        //$allProduk = mysqli_fetch_array($query);
                        //$row = mysqli_fetch_assoc($query);      
                        $i = 0;
                        while ($row = mysqli_fetch_assoc($query)) {
                            echo '<option value="' . $row['IdKategori'] . '">' . $row['Nama_Kategori'] . '</option>';
                        }
                        ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="desc">Deskripsi: </label>
                    <textarea class="form-control" rows="5" id="desc" name="desc" placeholder="ex: Spesifikasi: -AMD AM4 Socket -ProCool Power Connector -Multi-GPU SLI/CFX Support -14+2 Power Stages -DDR4, 4 x DIMM -2 x M.2 Sockets " required></textarea>
                </div>
            </form>


        </div>
        <div class="container-fluid">
            <button type="button" class="btn btn-primary mt-3 container-fluid uploadbutton">Upload</button>
        </div>
    </div>
    <script>
        /* **************************** SUBMIT BUTTON *************************************** */

        $(".uploadbutton").click(function() {
            $('.pinfo').submit();
            $('#gambar').submit();
        });

        /* **************************** SUBMIT BUTTON *************************************** */


        /* **************************** DRAG AND DROP *************************************** */
        Dropzone.autoDiscover = false;
        $(".dropzone").dropzone({
            addRemoveLinks: true,
            acceptedFiles: ".jpeg,.jpg,.png,.gif",
            uploadMultiple: false,
            autoProcessQueue: false,
            maxFiles: 1,
            init: function() {
                this.on("maxfilesexceeded", function(file) {
                    alert("Upload Only 1 File");
                    this.removeFile(this.files[0]);
                });
                this.on("sucess", function() {
                    $('.pinfo').submit();
                });
            },
            removedfile: function(file) {
                var name = file.name;
                $.ajax({
                    type: 'POST',
                    url: 'upload.php',
                    data: {
                        name: name,
                        request: 2
                    },
                    parrarelUploads: 1,
                    sucess: function(data) {
                        console.log('success: ' + data);
                    }
                });
                var _ref;
                return (_ref = file.previewElement) != null ? _ref.parentNode.removeChild(file.previewElement) : void 0;
            }

        });
        /* **************************** DRAG AND DROP *************************************** */
    </script>
</body>