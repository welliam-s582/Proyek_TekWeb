<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.22/css/jquery.dataTables.css">  
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.22/js/jquery.dataTables.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.js"></script>

<body>
    <div class="row">
        <div class="col-sm-12 col-md-6">

        </div>
        <div class="col-sm-12 col-md-6">

        </div>
    </div>

    <form action="addProduk.php" id="utilities" class="d-flex justify-content-between mb-3">
        <input type="submit" value="Add Product" class="btn btn-success">
    </form>
    
    
    <table id="myTable" class="table table-bordered table-hovered mt-3 display">
        <thead>
            <tr>
                <th>#<i class="fa fa-arrows-v" style="font-size:24px; color:black;"></i></th>
                <th>Nama<i class="fa fa-arrows-v" style="font-size:24px; color:black;"></i></th>   
                <th>Lihat Barang<i class="fa fa-arrows-v" style="font-size:24px; color:black;"></i></th>                 
                <th>Deskripsi<i class="fa fa-arrows-v" style="font-size:24px"></i></th>
                <th>Kategori<i class="fa fa-arrows-v" style="font-size:24px"></i></th>
                <th>Stok<i class="fa fa-arrows-v" style="font-size:24px"></i></th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $allproduk = mysqli_query($conn,"SELECT * FROM `produk` JOIN kategori where id_kategori = kategori.IdKategori");
                $i = 1;
                //$limit =3;
                while($row = mysqli_fetch_assoc($allproduk)) 
                {
                    echo '<tr>';
                    echo'<td>'.$i.'</td>';
                    echo'<td>'.$row['Nama'].'</td>';
                    echo'<td><button type="button" class="btn btn-success">Lihat</button></td>';
                    echo'<td>'.$row['Deskripsi'].'</td>';
                    echo'<td>'.$row['Nama_Kategori'].'</td>';
                    echo'<td>'.$row['Stock'].'</td>';
                    echo'<td><button type="button" class="btn btn-success">Edit</button></td>';
                    echo'<td><button id="delete-all-btn" class="btn btn-danger" data-id="'.$i.'" data-nama="'.$row['Nama'].'">Delete All</button></td>';
                    echo '</tr>';
                    $i++;
                }
            ?>
        </tbody>
    </table>

    <script>
        $(document).ready( function () {
         $('#myTable').DataTable();
        } );

        $("[id='delete-all-btn']").click(function(){
            var id=$(this).data('id');
            var name=$(this).data('nama');
            $.confirm({
                title: 'Are you sure ?',
                content:'You want to delete Product '+ name +'. Once you delete this Product, You cannot recover deleted data!',
                buttons: {
                    confirm: {
                        text: 'Confirm',
                        btnClass: 'btn-success',
                        keys: ['enter', 'shift'],
                        action: function(){
                            $.ajax({
                                    url: '/Proyek Tekweb/Proyek Tekweb/Seller/delete_product.php',
                                    method: 'POST',
                                    data: {
                                        id: id
                                    },
                                    success: function(data) {
                                        window.location = data['redirect'];
                                    },
                                    error: function($xhr, textStatus, errorThrown) 
                                    {
                                        alert($xhr.responseJSON['error']);
                                    }
                                });
                        }
                    },
                    cancel: {
                        text: 'Cancel',
                        btnClass: 'btn-secondary',
                        keys: ['enter', 'shift'],
                        action: function(){

                        }
                    }
                }
            });
        });
    </script>
</body>
