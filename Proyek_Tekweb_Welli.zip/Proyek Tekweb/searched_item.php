<?php
    include 'header.php'; 
    require 'connect.php';
  $search = $_POST['search'];

?>

<!DOCTYPE html>

    <html lang="en">
        <head>
        <title>Andre Komputer</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        </head>

        <body>
            <div class="row">
                <div class="col-12">
                    <div class="card-deck">
                        <?php
                            $query = mysqli_query($conn,"SELECT * FROM produk WHERE Nama LIKE '%$search%'" );
                            while($row = mysqli_fetch_assoc($query)) 
                            {
                                echo '<div class="card"> <img class="card-img-top" src='.$row['foto_filepath'].'>
                                <div class="card-body"><p class="card-title">'.$row['Nama'].'</p>
                                <b class="card-text">Rp'.$row['Harga'].'</b>
                                <p class="card-text" style="font-size:12px">Sisa '.$row['Stock'].'</p> </div>
                                </div>';
                            }
                        ?>

                    </div>
                </div>
            </div>
        </body>
    </html>



