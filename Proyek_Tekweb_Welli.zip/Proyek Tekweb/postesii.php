<html>
<body>

<?php

echo '<div>'.$_FILES['userfile']['name'].'</div>'
?>

</body>
</html>