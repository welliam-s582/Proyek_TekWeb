<?php
include "connect.php";


if ($_SERVER['REQUEST_METHOD'] == "POST") 
{
    $idkeranjang = $_POST['IdKeranjang'];
    #keranjang yg idcustomer yg status = 0 klo udh beli status = 1
    #beli -> if ada keranjang -> pesanan tok 
    #      -> else -> buat keranjang n pesanan baru dengan id keranjang barusan dibuat

    #status
    #0 -> blm dikirim ke penjual
    #1 -> sudah dikirim ke penjual blm di confirm 
    #2 -> sdh di confirm penjual
    #3 -> sudah dikirim oleh penjual
    #4 -> sudah sampai di customer belum di confirm customer
    #5 -> sudah di confirm customer (selesai)

    //masuk keranjang
    $query = mysqli_query($conn, ("SELECT * FROM keranjang"));
    if(!(mysqli_num_rows($query) == 0))
    {
        #ganti ke 1
        $sql = mysqli_query($conn, "UPDATE keranjang SET status = 1 WHERE IdKeranjang = $idkeranjang");
    }
    
    header("Location: home.php?purchased");
}
