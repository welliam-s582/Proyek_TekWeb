<?php
require "connect.php";
$total = 0;
$count = 0;
$idcustomer = 1;
?>


<!DOCTYPE html>
<html>
<title></title>

<head>
    <title></title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</head>

<body>
    <?php include "header.php" ?>
    <div class="container xl p-3">
        <form action="Keranjangsystem.php" method="POST">
            <div class="row">
                <div class="card col-7">
                    <div class="form-check">
                        <label class="form-check-label m-3">
                            <input type="checkbox" class="form-check-input" value="" id="select_all" checked> Pilih Semua Barang
                        </label>
                    </div>
                    <?php
                    $query = mysqli_query($conn, "SELECT * FROM keranjang LEFT JOIN pesanan on pesanan.IdKeranjang = keranjang.IdKeranjang LEFT JOIN produk ON produk.IdProduk = pesanan.id_Produk WHERE keranjang.status = 0");
                    $id = 0;
                    while ($row = mysqli_fetch_assoc($query)) {
                        $total = $total + $row['Harga'];
                        $count++;
                    ?>
                        <input type="hidden" value="<?php echo $row['IdKeranjang'] ?>" name="IdKeranjang">
                        <div class="form-check">
                            <label class="form-check-label m-3">
                                <input type="checkbox" class="form-check-input" id="<?php echo $id ?>" checked>
                                <div class="row">
                                    <img src="<?php echo $row['foto_filepath'] ?>" class="m-3" style="width: 200px; height: auto;">
                                    <div class="m-3 p-2">
                                        <b><?php echo $row['Nama'] ?></b> <br>
                                        <p class="text-danger" style="font-weight: bold;" id="harga"  data-id="<?php $id ?>"> Rp <?php echo $row['Harga'] ?> </p>
                                    </div>
                                </div>
                            </label>
                        </div>
                    <?php
                        $id++;
                    }
                    ?>

                </div>
                <div class="col-4 mx-2 py-3">
                    <p style="font-weight: bold;"> Ringkasan belanja </p>
                    <div class="row">
                        <p class="col-7">Total Harga </p>
                        <p style="text-align: right; font-weight: bold;" class="col-5 text-danger" id="totalbelanja"> Rp <?php echo $total; ?> </p>
                    </div>
                    <div class="row">
                        <button type="submit" class="btn btn-danger mx-3 col-11"> Beli Sekarang
                    </div>
                </div>
            </div>
        </form>





    </div>

    <script>
        $(function() {
            $(Document).ready(function() {
                $('#select_all').on('click', function() {
                    if (this.checked) {
                        $('.form-check-input').each(function() {
                            this.checked = true;
                        });
                    } else {
                        $('.form-check-input').each(function() {
                            this.checked = false;
                        });
                    }
                });
                $('.form-check-input').on('click', function() {
                    if ($('.form-check-input:checked').length == $('.form-check-input').length) {
                        $('#select_all').prop('checked', true);
                    } else {
                        $('#select_all').prop('checked', false);
                    }
                });
                $('.form-check-input').change(function() {
                    
                });
            });
        });
    </script>
</body>




</html>