<?php
    $carousel_limit = 4;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <style>    
        .card
        {
            max-width: 250px;  
            height: 450px;      
        } 
        .card img
        {
            max-height: 250px;  
        } 
        p {
            max-width: 150px;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        
    </style>
</head>
<body>
    <div class="all container-xl">
        <h2 class="font-weight-light">Top Picks</h2>

        <?php
            $kat=0;
            $getkategori = mysqli_query($conn,"SELECT * FROM `kategori` WHERE 1");
            while($rowk = mysqli_fetch_assoc($getkategori)) 
            {      
                echo '<h2 class="pt-3">'.$rowk['Nama'].'</h2>';
            ?> 
            <!-- carousel container -->
            <div class="carousel container-xl">
            <!--Carousel Wrapper-->
            <?php echo'<div id="topPick'.$kat.'" class="carousel slide carousel-multi-item" data-ride="carousel">';?>

            <!--Controls-->
            <div class="controls-top">
                <?php echo '<a class="btn-floating" href="#topPick'.$kat.'" data-slide="prev"><i class="fa fa-chevron-left"></i></a>';?>
                <?php echo '<a class="btn-floating" href="#topPick'.$kat.'" data-slide="prev"><i class="fa fa-chevron-right"></i></a>';?>
            </div>
            <!--/.Controls-->
            
            <div class="carousel-inner" role="listbox">
        <?php
            $kategori = $rowk['IdKategori'];
            $query = mysqli_query($conn,"SELECT * FROM `produk` WHERE id_kategori = $kategori");
            //$allProduk = mysqli_fetch_array($query);
            //$row = mysqli_fetch_assoc($query);      
            $i = 0;
            //$limit =3;
            $j=0;
            while($row = mysqli_fetch_assoc($query)) 
            {
                if($i==0)
                {?>
                    <div class="carousel-item active">
                        <div class="row">
                            <?php
                                do
                                {?>
                                    <div class="col">
                                        <?php echo '<div class="card mb-2 product" data-product-id="'.$row['IdProduk'].'">';?>
                                        <?php echo '<img class="card-img-top" src="'.$row['foto_filepath'].'" >'?>
                                        <!-- <img class="card-img-top" src="https://mdbootstrap.com/img/Photos/Horizontal/Food/4-col/img%20(53).jpg" alt="Card image cap"> -->
                                        <div class="card-body">
                                            <?php echo'<h4 class="card-title">'.$row['Nama'].'</h4>';?>
                                            <?php echo'<p class="card-text">'.$row['Deskripsi'].'</p>'?>
                                            <?php echo'<div class="d-flex align-items-end"><p>'.$row['Harga'].'</p></div>'?>
                                            
                                        </div>
                                        </div>
                                    </div>

                                <?php
                                $j++;
                                }while(($row = mysqli_fetch_assoc($query)) && $j<$carousel_limit);
                            ?>
                            
                        </div>

                    </div>
                    <!--/.First slide-->
                <?php
                $i++;
                }            
            else
            {?>
                <!--Second slide-->
                <div class="carousel-item">
                    <div class="row">
                        <?php                    
                            do
                            {?>
                                <div class="col">
                                    <form action="ProductPage.php">
                                        <div class="card mb-2 product" onclick="this.parentNode.submit()">
                                        <?php echo '<img class="card-img-top" src="'.$row['foto_filepath'].'"> '?>
                                        <div class="card-body">
                                            <?php echo'<h4 class="card-title">'.$row['Nama'].'</h4>';?>
                                            <?php echo'<p class="card-text">'.$row['Deskripsi'].'</p>'?>
                                            <?php echo'<p class="card-price d-flex align-items-end">'.$row['Harga'].'</p>'?>                                            
                                        </div>
                                        </div>
                                        <?php echo '<input type="hidden" id="id_produk" name="id_produk" value="'.$row['IdProduk'].'">'?>

                                    </form>
                                </div>

                            <?php
                            $j++;
                            }while(($row = mysqli_fetch_assoc($query)) && $j<$carousel_limit);
                        ?>
                        
                    </div>

                </div>
                <!--/.Second slide-->
            <?php
                }

                
            }
        
        ?>
       
        <div class="control">
            <?php echo'<a class="carousel-control-prev" href="#topPick'.$kat.'" data-slide="prev">';?>
                <i class="fa fa-angle-double-left pt-5" style="font-size:36px; color:dodgerblue; opacity:1"></i>
            </a>
            <?php echo'<a class="carousel-control-next" href="#topPick'.$kat.'" data-slide="next">';?>
                <i class="fa fa-angle-double-right pt-5 " style="font-size:36px; color:dodgerblue"></i>
            </a>
        </div>
    </div>
</div>
<!-- carousel wrapper ends       -->


      
      </div>
      <?php
      $kat++;
        }
    ?>
      <!-- carousel container -->
    
</div>

</body>
<script>   
    
</script>
</html>